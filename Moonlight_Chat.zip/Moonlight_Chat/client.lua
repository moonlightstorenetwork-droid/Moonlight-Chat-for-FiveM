local QBCore = exports['qb-core']:GetCoreObject()

local chatOpen = false

RegisterCommand('openChat', function()
    if not chatOpen then
        SetNuiFocus(true, true)
        SendNUIMessage({ action = "openChat" })
        chatOpen = true
        TriggerServerEvent("rpchat:requestCommands")
    end
end)

RegisterKeyMapping('openChat', 'Abrir chat', 'keyboard', 'T')

RegisterNUICallback("sendMessage", function(data, cb)
    SetNuiFocus(false, false)
    chatOpen = false

    if data.message and data.message ~= "" then
        local msg = data.message

        if string.sub(msg, 1, 1) == "/" then
            local args = {}
            for word in string.gmatch(msg, "[^%s]+") do
                table.insert(args, word)
            end
            local command = string.sub(args[1], 2):lower()
            local text = table.concat(args, " ", 2)

            if command == "me" or command == "do" or command == "ooc" or command == "clear" then
                TriggerServerEvent("rpchat:processMessage", command, text)
            else
                ExecuteCommand(string.sub(msg, 2))
            end
        end
    end
    cb("ok")
end)

RegisterNUICallback("cancelChat", function(_, cb)
    SetNuiFocus(false, false)
    chatOpen = false
    cb("ok")
end)

RegisterNetEvent("rpchat:sendProximityMessage", function(senderId, message, color)
    local sender = GetPlayerFromServerId(senderId)

    if sender ~= -1 then
        local senderPed = GetPlayerPed(sender)
        local senderCoords = GetEntityCoords(senderPed)
        local myCoords = GetEntityCoords(PlayerPedId())
        local dist = #(senderCoords - myCoords)

        if dist < 8.0 then -- Radio de proximidad ajustable
            SendNUIMessage({
                type = "chatMessage",
                message = message,
                color = color
            })
        end
    end
end)

RegisterNetEvent("rpchat:sendCommands", function(cmds)
    SendNUIMessage({ type = "setCommands", commands = cmds })
end)

RegisterNetEvent("rpchat:clearChat", function()
    SendNUIMessage({ type = "clearChat" })
end)