fx_version 'cerulean'
game 'gta5'

author 'jayse'
description 'Moonlight Chat con proximidad'
version '1.0.0'

ui_page 'chat_ui.html'

files {
    'chat_ui.html'
}

client_script 'client.lua'
server_script 'server.lua'

dependency 'qb-core'