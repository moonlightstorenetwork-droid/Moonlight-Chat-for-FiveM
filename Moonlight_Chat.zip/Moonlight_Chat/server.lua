local QBCore = exports['qb-core']:GetCoreObject()

local comandos = {"/me", "/do", "/ooc", "/tx", "/ayuda", "/report", "/clear"}

RegisterNetEvent("rpchat:processMessage")
AddEventHandler("rpchat:processMessage", function(type, msg)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local icName = Player and Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname or "Desconocido"
    local name = GetPlayerName(src)

    if type == "me" then
        TriggerClientEvent("rpchat:sendProximityMessage", -1, src, "[ME] " .. icName .. ": " .. msg, "#FF69B4")
    elseif type == "do" then
        TriggerClientEvent("rpchat:sendProximityMessage", -1, src, "[DO] " .. icName .. ": " .. msg, "#87CEFA")
    elseif type == "ooc" then
        TriggerClientEvent("rpchat:sendProximityMessage", -1, src, "[OOC] " .. icName .. ": " .. msg, "#AAAAAA")
    elseif type == "clear" then
        TriggerClientEvent("rpchat:clearChat", src)
        return
    else
        TriggerClientEvent("rpchat:sendProximityMessage", -1, src, "[" .. type .. "] " .. icName .. ": " .. msg, "#FFFFFF")
    end
end)

RegisterNetEvent("rpchat:clearChat")
AddEventHandler("rpchat:clearChat", function()
    
end)

RegisterNetEvent("rpchat:requestCommands")
AddEventHandler("rpchat:requestCommands", function()
    local src = source
    TriggerClientEvent("rpchat:sendCommands", src, comandos)
end)